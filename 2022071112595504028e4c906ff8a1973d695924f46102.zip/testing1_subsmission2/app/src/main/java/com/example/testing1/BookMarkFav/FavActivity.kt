package com.example.testing1.BookMarkFav

import android.content.Intent
import android.content.res.ColorStateList
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.annotation.ColorRes
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.testing1.Entitas.FavEntitas
import com.example.testing1.ListUserAdapter
import com.example.testing1.MoveActivity
import com.example.testing1.Pabrik.PabrikFav
import com.example.testing1.R
import com.example.testing1.Repository.FavRepository
import com.example.testing1.adaptor.FavAdaptor
import com.example.testing1.api.ItemsItem
import com.example.testing1.databinding.ActivityFavBinding
import com.example.testing1.viewmodels.FavViewModel
import com.google.android.material.floatingactionbutton.FloatingActionButton

class FavActivity : AppCompatActivity() {

    private lateinit var binding: ActivityFavBinding
    private lateinit var viewFavorit: FavViewModel
    private lateinit var adapter: FavAdaptor



    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        binding = ActivityFavBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewFavorit = ViewModelProvider(this, PabrikFav.getInstance(this))
            .get(FavViewModel::class.java)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "User Favorite"

        binding.rvFav.layoutManager = LinearLayoutManager(this)
        viewFavorit.getBookmarkedFav().observe(this){ users ->
            adapter = FavAdaptor(users as ArrayList<FavEntitas>)
                binding.rvFav.adapter = adapter
            adapter.setOnItemClickCallback(object : FavAdaptor.OnItemClickCallback {
                override fun onItemClicked(data: String) {
                    val intent = Intent(this@FavActivity,MoveActivity::class.java)
                    intent.putExtra(MoveActivity.EXTRA_USER,data)
                    startActivity(intent)
                }

                override fun onFavClicked(fav: FavEntitas) {
                    viewFavorit.deleteBookmark(fav.login)
                    adapter.notifyDataSetChanged()
                }

            })
            }
        }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when(item.itemId){
            android.R.id.home -> {
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }

    }
    }

