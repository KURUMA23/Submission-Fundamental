package com.example.testing1.Fragment

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.testing1.ListUserAdapter
import com.example.testing1.viewmodels.MoveViewModels

class FollowFragment_Backup : Fragment() {
    companion object{
        private const val ARG_SECTION_NUMBERS = "section_number"
        private const val ARG_USER_ID = "user_id"

        @JvmStatic
        fun newInstance(index: Int,username: String) =
            FollowFragment_Backup().apply {
                arguments = Bundle().apply {
                    putInt(ARG_SECTION_NUMBERS, index)
                    putString(ARG_USER_ID, username)
                }
            }
    }
    private lateinit var adapter: ListUserAdapter
    private lateinit var viewModel: MoveViewModels


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val recyclerView: RecyclerView = view.findViewById(com.example.testing1.R.id.rv_follow)

        val section = arguments?.getInt(ARG_SECTION_NUMBERS, 0)
        val username = arguments?.getString(ARG_USER_ID)

        recyclerView.layoutManager = LinearLayoutManager(context)
        adapter = ListUserAdapter(arrayListOf())
        recyclerView.adapter = adapter

    }
}