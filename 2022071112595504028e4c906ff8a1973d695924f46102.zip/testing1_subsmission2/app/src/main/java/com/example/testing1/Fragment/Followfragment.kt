package com.example.testing1.Fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.testing1.adaptor.FollowAdapter
import com.example.testing1.api.ListFollowersItem
import com.example.testing1.databinding.FragmentFollowBinding
import com.example.testing1.viewmodels.MoveViewModels

class Followfragment : Fragment() {

    private lateinit var adapter: FollowAdapter
    private lateinit var viewModel: MoveViewModels
    private lateinit var recyclerView: RecyclerView
    private var _binding: FragmentFollowBinding? = null
    private val binding get() =_binding!!
    private val listing = ArrayList<ListFollowersItem>()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentFollowBinding.inflate(inflater,container,false)


        viewModel = ViewModelProvider(requireActivity()).get(MoveViewModels::class.java)
        viewModel.isLoadingFollowers.observe(viewLifecycleOwner){status ->
            showloadingfollowers(status)
        }
        viewModel.listFollowers().observe(viewLifecycleOwner){
            listing.addAll(it)
            recyclerView = binding.rvFollow
            recyclerView.layoutManager = LinearLayoutManager(context)
            adapter = FollowAdapter(listing)
            recyclerView.adapter = adapter
        }
        return binding.root
    }
    private fun showloadingfollowers(isLoading: Boolean){
        binding.PBFollowers.visibility = if (isLoading) View.VISIBLE else View.GONE
    }
}