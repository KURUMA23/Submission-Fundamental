package com.example.testing1.Helper

import android.content.Context
import android.content.SharedPreferences

class PrefHelper(context: Context) {
    private val PREFS_NAME = "Dark Mode"
    private var sharedPref:SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    val editor:SharedPreferences.Editor = sharedPref.edit()

    fun put(key: String,value: Boolean){
        editor.putBoolean(key,value)
            .apply()
    }
    fun getboolean(key:String): Boolean{
        return sharedPref.getBoolean(key,false)
    }
}