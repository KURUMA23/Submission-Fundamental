package com.example.testing1


import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.annotation.StringRes
import androidx.lifecycle.ViewModelProvider
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.example.testing1.adaptor.PagersAdaptor
import com.example.testing1.databinding.ActivityMoveBinding
import com.example.testing1.viewmodels.MoveViewModels
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator

class MoveActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMoveBinding
    private lateinit var userData: String
    private lateinit var viewModel: MoveViewModels
    private var isbookmark : Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMoveBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.title = "User Detail"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        userData = intent.getStringExtra(EXTRA_USER)!!




        viewModel(userData)
        tablayout(userData)

    }


    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }

    private fun tablayout(username: String) {
        val pagersAdaptor = PagersAdaptor(this)
        val viewPager: ViewPager2 = binding.vpThis
        pagersAdaptor.getUsername(username)
        viewPager.adapter = pagersAdaptor
        val tabs: TabLayout = binding.tabFollow
        TabLayoutMediator(tabs, viewPager) { tab, position ->
            tab.text = resources.getString(TAB_TITLES[position])

        }.attach()
        supportActionBar?.elevation = 0f

    }

    private fun viewModel(data: String) {
        Toast.makeText(this, data, Toast.LENGTH_SHORT).show()
        val pabrikFollow = PabrikFollow.getInstance(data, this)
        viewModel = ViewModelProvider(this, pabrikFollow)
            .get(MoveViewModels::class.java)
        viewModel.gabungan(data)
        viewModel.detailUsers().observe(this) { user ->
            binding.useRname.text = user.login
            binding.evNama.text = user.name
            binding.perusahaan.text = user.company
            binding.ecLokasi.text = user.location
            binding.vtRepositori.text = user.publicRepos.toString()
            binding.vtFollowing.text = user.following.toString()
            binding.vtFollowers.text = user.followers.toString()
            Glide.with(this@MoveActivity)
                .load(user.avatarUrl)
                .into(binding.evUser)
            Log.v("avatarUrl", user.avatarUrl)

            binding.btnFav.setOnClickListener {
                if (isbookmark){
                    viewModel.deleteFav(userData)
                } else{
                    viewModel.saveFav(user)
                }
            }

        }
        viewModel.isLoadingDetailUser.observe(this) { status ->
            showloading(status)
        }
        viewModel.isBookmarkedFav(userData).observe(this){ isbookmark ->
            this.isbookmark = isbookmark
            if (isbookmark){
               binding.btnFav.setImageResource(R.drawable.ic_baseline_bookmark_24)
            }  else {
                binding.btnFav.setImageResource(R.drawable.ic_baseline_bookmark_border_24)
            }
        }
    }

    private fun showloading(isLoading: Boolean) {
        binding.pbDetail.visibility = if (isLoading) View.VISIBLE else View.GONE
    }

    companion object {
        const val EXTRA_USER = "extra_user"

        @StringRes
        private val TAB_TITLES = intArrayOf(
            R.string.followers,
            R.string.following
        )
    }

}