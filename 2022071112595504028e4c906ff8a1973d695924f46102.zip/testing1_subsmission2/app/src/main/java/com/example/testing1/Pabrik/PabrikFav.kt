package com.example.testing1.Pabrik

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.testing1.Repository.FavRepository
import com.example.testing1.viewmodels.FavViewModel

class PabrikFav private constructor(private val db: FavRepository): ViewModelProvider.Factory {

    companion object {
        @Volatile
        private var instance: PabrikFav? = null

        fun getInstance(context: Context): PabrikFav =
            instance ?: synchronized(this) {
                instance ?: PabrikFav(
                    FavRepository.getInstance(context)
                )
            }
    }

    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return FavViewModel(db) as T
    }
}