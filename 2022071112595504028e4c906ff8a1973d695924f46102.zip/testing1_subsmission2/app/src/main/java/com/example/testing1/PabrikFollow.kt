package com.example.testing1

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.testing1.Repository.FavRepository
import com.example.testing1.di.Injection
import com.example.testing1.viewmodels.MoveViewModels

class PabrikFollow private constructor(var data: String, private val favRepository: FavRepository) :
    ViewModelProvider.NewInstanceFactory() {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MoveViewModels::class.java)) {
            return MoveViewModels(data, favRepository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class: " + modelClass.name)
    }

    companion object {
        @Volatile
        private var instance: PabrikFollow? = null
        fun getInstance(data: String, context: Context): PabrikFollow =
            instance ?: synchronized(this) {
                instance ?: PabrikFollow(data, Injection.provideRepository(context))
            }.also { instance = it }
    }
}