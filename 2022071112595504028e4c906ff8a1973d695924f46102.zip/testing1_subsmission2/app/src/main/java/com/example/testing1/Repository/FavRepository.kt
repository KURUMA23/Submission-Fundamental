package com.example.testing1.Repository

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MediatorLiveData
import androidx.room.Room
import com.example.testing1.Entitas.FavEntitas
import com.example.testing1.api.ApiService
import com.example.testing1.api.DetailUser
import com.example.testing1.room.FavDao
import com.example.testing1.room.FavDatabase
import com.example.testing1.utilitas.AppExecutors
import retrofit2.Call
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import javax.security.auth.callback.Callback


class FavRepository private constructor(
    private val favDao: FavDao, private val executor: ExecutorService
) {
    fun getBookmarkedFav(): LiveData<List<FavEntitas>> {
        return favDao.loadAll()
    }

    fun setBookmarkedFav(user: FavEntitas) {
        executor.execute {
            favDao.insertFav(user)
        }
    }

    fun deleteBookmarkedFav(user: String) {
        executor.execute {
            favDao.delete(user)
        }
    }

    fun isBookmarkedFav(login: String): LiveData<Boolean> {
        return favDao.isNewsBookmarked(login)
    }

    companion object {
        @Volatile
        private var instance: FavRepository? = null
        fun getInstance(
            context: Context
        ): FavRepository {
            return instance ?: synchronized(this) {
                if (instance == null) {
                    val database = FavDatabase.getInstance(context)
                    instance = FavRepository(
                        database.favDao(),
                        Executors.newSingleThreadExecutor()
                    )
                }
                return instance as FavRepository
            }
        }

    }
}