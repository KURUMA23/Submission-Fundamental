package com.example.testing1.Repository

import android.content.Context
import androidx.room.Room
import com.example.testing1.room.FavDao
import com.example.testing1.room.FavDatabase


//class FavRepositoryBackup(private val context: Context){
//    private val db = Room.databaseBuilder(context,FavDatabase::class.java, "favgithub.db")
//        .allowMainThreadQueries()
//        .build()
//
//    val FavDao = db.favDao()
//}