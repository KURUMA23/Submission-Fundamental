package com.example.testing1.adaptor

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.testing1.Entitas.FavEntitas
import com.example.testing1.databinding.ItemRowUserBinding
import com.example.testing1.databinding.UserDeleteBinding

class FavAdaptor(
    private val listAccount : ArrayList<FavEntitas>
) : RecyclerView.Adapter<ViewHolderAccount>() {

    private lateinit var onItemClickCallback: OnItemClickCallback

    fun setOnItemClickCallback(onItemClickCallback: OnItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolderAccount {
        val binding = UserDeleteBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )

        return ViewHolderAccount(binding)
    }

    override fun onBindViewHolder(holder: ViewHolderAccount, position: Int) {
        with(holder){
            with(listAccount[position]){
                Glide.with(binding.imgItemPhoto)
                    .load(avatar_url)
                    .circleCrop()
                    .into(binding.imgItemPhoto)



                binding.tvItemName.text = this.login
                holder.itemView.setOnClickListener{
                    onItemClickCallback.onItemClicked(listAccount[holder.adapterPosition].login)
                }
                binding.btnFav2.setOnClickListener{
                    onItemClickCallback.onFavClicked(
                        listAccount[holder.adapterPosition]
                    )
                }
            }
        }
    }

    override fun getItemCount(): Int {
        return listAccount.size
    }
    interface OnItemClickCallback{
        fun onItemClicked(data:String)
        fun onFavClicked(fav: FavEntitas)
    }
}
class ViewHolderAccount (
    val binding : UserDeleteBinding
) : RecyclerView.ViewHolder(binding.root)