package com.example.testing1.adaptor

import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.example.testing1.Fragment.Followfragment
import com.example.testing1.Fragment.FollowingFragment

class PagersAdaptor(activity: AppCompatActivity): FragmentStateAdapter(activity) {

    var username: String = ""

    fun getUsername(username: String){
        this.username = username
    }
    override fun getItemCount(): Int {
        return 2
    }

    override fun createFragment(position: Int): Fragment {
        var fragment:Fragment?=null
        when (position){
            0 -> fragment = Followfragment()
            1 -> fragment = FollowingFragment()
        }
        return fragment as Fragment
    }
}