package com.example.testing1.api

import com.example.testing1.User
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiService {

    @GET("user")
    fun getAll():Call <ArrayList<User>>

    @GET("users/{user_id}")
    fun getUser(
        @Path("user_id") user_id: String
    ):Call <DetailUser>

    @GET("users/{username}/followers")
    fun getFollowers(
        @Path("username") username: String
    ):Call <ArrayList<ListFollowersItem>>

    @GET("users/{username}/following")
    fun getFollowing(
        @Path("username") username: String
    ):Call <ArrayList<ListFollowingsItem>>

    @GET("search/users")
    fun getSearchUser(
        @Query("q") username: String
    ):Call <SearchUser>
}