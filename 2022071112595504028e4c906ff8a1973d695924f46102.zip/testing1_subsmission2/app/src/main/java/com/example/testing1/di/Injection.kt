package com.example.testing1.di

import android.content.Context
import com.example.testing1.Config.ApiConfig
import com.example.testing1.Repository.FavRepository
//import com.example.testing1.Repository.FavRepository
import com.example.testing1.room.FavDatabase
import com.example.testing1.utilitas.AppExecutors

object Injection {
    fun provideRepository(context: Context): FavRepository {
        val apiService = ApiConfig.getApiService()
        val database = FavDatabase.getInstance(context)
        val dao = database.favDao()
        val appExecutors = AppExecutors()
        return FavRepository.getInstance(context)
    }
}