package com.example.testing1.room

import androidx.lifecycle.LiveData
import androidx.room.*
import com.example.testing1.Entitas.FavEntitas

@Dao
interface FavDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertFav(user: FavEntitas)

    @Query("SELECT * FROM User")
    fun loadAll(): LiveData<List<FavEntitas>>

    @Query("SELECT EXISTS(SELECT * FROM user WHERE login = :login )")
    fun isNewsBookmarked(login: String): LiveData<Boolean>

    @Query("DELETE FROM user WHERE login = :login")
    fun delete(login: String)
}