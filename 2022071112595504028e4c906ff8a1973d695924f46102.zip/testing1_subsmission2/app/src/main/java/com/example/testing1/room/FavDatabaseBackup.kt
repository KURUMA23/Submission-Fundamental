package com.example.testing1.room

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.testing1.Entitas.FavEntitas

//@Database(entities = [FavEntitas::class], version = 1, exportSchema = false)
//abstract class FavDatabaseBackup: RoomDatabase() {
//    abstract fun favDao(): FavDao
//}