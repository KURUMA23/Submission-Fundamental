package com.example.testing1.viewmodels

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.testing1.Entitas.FavEntitas
import com.example.testing1.Repository.FavRepository
import kotlinx.coroutines.launch

class FavViewModel (private val favRepository: FavRepository) : ViewModel() {
    fun getBookmarkedFav() = favRepository.getBookmarkedFav()
    fun deleteBookmark(data:String) = favRepository.deleteBookmarkedFav(data)


}